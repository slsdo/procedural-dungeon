import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class DungeonGenerator extends PApplet {

/* Procedural Dungeon Generator
   www.futuredatalab.com/proceduraldungeon/
   
   Compatible with Processing 3.0.1 and ControlP5 2.2.5 */



World world;
ControlP5 cp5;

public void setup() {
  
  
  world = new World();
  refresh();
  controlUI();
}

public void draw() {
}

public void keyPressed() {
  if (key == ' ') {
    generate();
  }
}
// Parameters
public int g_width = 40; // Grid width
public int g_height = 30; // Grid height
public int g_layout = 0; // Layout type
public boolean g_show = true; // Display grid
public boolean d_show = true; // Display information
// Basic
public int room_min_size = 9;
public int room_max_size = 16;
public int corridor_num = 2;
public int corridor_weight = 4;
public int turning_weight = 4;
public int room_type = 0; // Room type
// CA
public int wall_fill = 40; // Openess
public int generate_iter = 4; // Cycles
public int cleanup_iter = 3; // Cycles
// BSP
public int min_room_num = (g_width*g_height)/100; // Minimum number of rooms
public int min_room_size = 5; // Min room size
// Build
public int max_rm_w = 8; // Max room width
public int max_rm_h = 8; // Max room height
public int max_corr_l = 6; // Max corridor length
public int obj_num = 10; // Number of objects

public void controlUI()
{
  // Position offsets
  int xoffset = 10;
  int yoffset = 5;
  int settingoffset = 10;
   
  cp5 = new ControlP5(this);
  
  // Group menu items
  ControlGroup ui = cp5.addGroup("Settings").setPosition(615, 0).setWidth(185);
  ui.setBackgroundColor(color(0, 200));
  ui.setBackgroundHeight(height);
  
  // Canvas settings and more
  Textlabel textCanvas = cp5.addTextlabel("Setting").setText("Setting").setPosition(xoffset, settingoffset);
  textCanvas.setGroup(ui);
  textCanvas.setColorValue(color(200));
  
  Button buttonGenerate = cp5.addButton("Generate").setValue(0).setPosition(xoffset, settingoffset + yoffset*3).setSize(50, 30);
  buttonGenerate.setId(0);
  buttonGenerate.setGroup(ui);
  
  Button buttonRandom = cp5.addButton("Random").setValue(0).setPosition(xoffset + 55, settingoffset + yoffset*3).setSize(50, 30);
  buttonRandom.setId(1);
  buttonRandom.setGroup(ui);
  
  Button buttonStart = cp5.addButton("Save").setValue(0).setPosition(xoffset + 110, settingoffset + yoffset*3).setSize(50, 30);
  buttonStart.setId(2);
  buttonStart.setGroup(ui);
  
  Slider sliderWidth = cp5.addSlider("g_width").setRange(1, 50).setValue(g_width).setPosition(xoffset, settingoffset + yoffset*11).setSize(120, 10);
  sliderWidth.setId(3);
  sliderWidth.setGroup(ui);
  
  Slider sliderHeight = cp5.addSlider("g_height", 1, 50).setValue(g_height).setPosition(xoffset, settingoffset + yoffset*15).setSize(120, 10);
  sliderHeight.setId(4);
  sliderHeight.setGroup(ui);

  Textlabel layoutType = cp5.addTextlabel("Layout Type").setText("Layout Type").setPosition(xoffset + 1, settingoffset + yoffset*19);
  layoutType.setGroup(ui);

  DropdownList dropLayoutType = cp5.addDropdownList("Layouts").setPosition(xoffset, settingoffset + yoffset*24).setSize(70, 120).close();
  switch (g_layout) {
    case 0: dropLayoutType.getCaptionLabel().set("Basic"); break;
    case 1: dropLayoutType.getCaptionLabel().set("Cave"); break;
    case 2: dropLayoutType.getCaptionLabel().set("BSP"); break;
    case 3: dropLayoutType.getCaptionLabel().set("Build"); break;
  }
  dropLayoutType.addItem("Basic", 0);
  dropLayoutType.addItem("Cave", 1);
  dropLayoutType.addItem("BSP", 2);
  dropLayoutType.addItem("Build", 3);
  dropLayoutType.setId(21);
  dropLayoutType.setGroup(ui);
  
  Textlabel roomType = cp5.addTextlabel("Room Type").setText("Room Type").setPosition(xoffset + 86, settingoffset + yoffset*19);
  roomType.setGroup(ui);
  
  DropdownList dropRoomType = cp5.addDropdownList("Room").setPosition(xoffset + 85, settingoffset + yoffset*24).setSize(70, 120).close();
  if (g_layout == 0) {
    switch (room_type) {
      case 0: dropRoomType.getCaptionLabel().set("Scattered"); break;
      case 1: dropRoomType.getCaptionLabel().set("Sparse"); break;
      case 2: dropRoomType.getCaptionLabel().set("Dense"); break;
      case 3: dropRoomType.getCaptionLabel().set("Complex"); break;
    }
    dropRoomType.addItem("Scattered", 0);
    dropRoomType.addItem("Sparse", 1);
    dropRoomType.addItem("Dense", 2);
    dropRoomType.addItem("Complex", 3);
    dropRoomType.setId(22);
    dropRoomType.setGroup(ui);
  }
  else dropRoomType.getCaptionLabel().set("N/A");
    dropRoomType.setGroup(ui);

  Textlabel debugCanvas = cp5.addTextlabel("Debug").setText("Debug").setPosition(xoffset, settingoffset + yoffset*37);
  debugCanvas.setGroup(ui);
  debugCanvas.setColorValue(color(200));

  Toggle toggleInfo = cp5.addToggle("Info", d_show).setPosition(xoffset + 0, settingoffset + yoffset*41).setSize(10, 10);
  toggleInfo.setId(5);
  toggleInfo.setGroup(ui);
  
  Toggle toggleGrid = cp5.addToggle("Grid", g_show).setPosition(xoffset + 25, settingoffset + yoffset*41).setSize(10, 10);
  toggleGrid.setId(6);
  toggleGrid.setGroup(ui);

  Textlabel basicCanvas = cp5.addTextlabel("Basic").setText("Basic").setPosition(xoffset, settingoffset + yoffset*47);
  basicCanvas.setGroup(ui);
  basicCanvas.setColorValue(color(200));
  
  Slider sliderRmMinSize = cp5.addSlider("room_min_size").setRange(4, 36).setValue(room_min_size).setPosition(xoffset + 1, settingoffset + yoffset*50).setSize(90, 10);
  sliderRmMinSize.setId(7);
  sliderRmMinSize.setGroup(ui);

  Slider sliderRmMaxSize = cp5.addSlider("room_max_size").setRange(9, 49).setValue(room_max_size).setPosition(xoffset + 1, settingoffset + yoffset*54).setSize(90, 10);
  sliderRmMaxSize.setId(8);
  sliderRmMaxSize.setGroup(ui);
  
  Slider sliderCorrNum = cp5.addSlider("corridor_num").setRange(1, 10).setValue(corridor_num).setPosition(xoffset + 1, settingoffset + yoffset*58).setSize(90, 10);
  sliderCorrNum.setId(9);
  sliderCorrNum.setGroup(ui);

  Slider sliderPathCorrW = cp5.addSlider("corridor_weight").setRange(0, 10).setValue(corridor_weight).setPosition(xoffset + 1, settingoffset + yoffset*62).setSize(90, 10);
  sliderPathCorrW.setId(10);
  sliderPathCorrW.setGroup(ui);
  
  Slider sliderPathTurnW = cp5.addSlider("turning_weight").setRange(0, 10).setValue(turning_weight).setPosition(xoffset + 1, settingoffset + yoffset*66).setSize(90, 10);
  sliderPathTurnW.setId(11);
  sliderPathTurnW.setGroup(ui);
  
  Textlabel caCanvas = cp5.addTextlabel("Cellular Automata").setText("Cellular Automata").setPosition(xoffset, settingoffset + yoffset*70);
  caCanvas.setGroup(ui);
  caCanvas.setColorValue(color(200));
  
  Slider sliderReps = cp5.addSlider("wall_fill").setRange(10, 90).setValue(wall_fill).setPosition(xoffset + 1, settingoffset + yoffset*73).setSize(90, 10);
  sliderReps.setId(12);
  sliderReps.setGroup(ui);

  Slider sliderGenIt = cp5.addSlider("generate_iter").setRange(1, 20).setValue(generate_iter).setPosition(xoffset + 1, settingoffset + yoffset*77).setSize(90, 10);
  sliderGenIt.setId(13);
  sliderGenIt.setGroup(ui);

  Slider sliderClIt = cp5.addSlider("cleanup_iter").setRange(0, 10).setValue(cleanup_iter).setPosition(xoffset + 1, settingoffset + yoffset*81).setSize(90, 10);
  sliderClIt.setId(14);
  sliderClIt.setGroup(ui);

  Textlabel bspCanvas = cp5.addTextlabel("BSP", "BSP").setPosition(xoffset, settingoffset + yoffset*85);
  bspCanvas.setGroup(ui);
  bspCanvas.setColorValue(color(200));
  
  Slider sliderRmNum = cp5.addSlider("min_room_num").setRange(1, (g_width*g_height)/50).setValue(min_room_num).setPosition(xoffset + 1, settingoffset + yoffset*88).setSize(90, 10);
  sliderRmNum.setId(15);
  sliderRmNum.setGroup(ui);
  
  Slider sliderMinSize = cp5.addSlider("min_room_size").setRange(1, 10).setValue(min_room_size).setPosition(xoffset + 1, settingoffset + yoffset*92).setSize(90, 10);
  sliderMinSize.setId(16);
  sliderMinSize.setGroup(ui);
    
  Textlabel buildCanvas = cp5.addTextlabel("Build").setText("Build").setPosition(xoffset, settingoffset + yoffset*96);
  buildCanvas.setGroup(ui);
  buildCanvas.setColorValue(color(200));
  
  Slider sliderMaxRmw = cp5.addSlider("max_rm_w").setRange(5, 16).setValue(max_rm_w).setPosition(xoffset + 1, settingoffset + yoffset*99).setSize(90, 10);
  sliderMaxRmw.setId(17);
  sliderMaxRmw.setGroup(ui);
  
  Slider sliderMaxRmh = cp5.addSlider("max_rm_h").setRange(5, 16).setValue(max_rm_h).setPosition(xoffset + 1, settingoffset + yoffset*103).setSize(90, 10);
  sliderMaxRmh.setId(18);
  sliderMaxRmh.setGroup(ui);

  Slider sliderMaxCorrl = cp5.addSlider("max_corr_l").setRange(3, 10).setValue(max_corr_l).setPosition(xoffset + 1, settingoffset + yoffset*107).setSize(90, 10);
  sliderMaxCorrl.setId(19);
  sliderMaxCorrl.setGroup(ui);

  Slider sliderObjNum = cp5.addSlider("obj_num").setRange(1, 40).setValue(obj_num).setPosition(xoffset + 1, settingoffset + yoffset*111).setSize(90, 10);
  sliderObjNum.setId(20);
  sliderObjNum.setGroup(ui);
}

public void controlEvent(ControlEvent theEvent)
{
  // Event handler
  if(theEvent.isController()) {
    switch(theEvent.getController().getId()) {
      case 0: { generate(); break; } // Generate current world
      case 1: { generate_random(); break; } // Generate random world
      case 2: { selectInput("Select a file to write to:", "fileSelected"); break; } // Opens file chooser
      case 3: { // Adjust grid width
        g_width = PApplet.parseInt(theEvent.getController().getValue());
        if (cp5.getController("Layouts").getValue() == 2 && g_width < 5) {
          g_width = 5;
          theEvent.getController().setValue(g_width);
        }
        if ((g_width*g_height)/50 > 1) cp5.getController("min_room_num").setMax((g_width*g_height)/50);
        break;
      }
      case 4: { // Adjust grid height
        g_height = PApplet.parseInt(theEvent.getController().getValue());
        if (cp5.getController("Layouts").getValue() == 2 && g_height < 5) {
          g_height = 5;
          theEvent.getController().setValue(g_height);
        }
        if ((g_width*g_height)/50 > 1) cp5.getController("min_room_num").setMax((g_width*g_height)/50);
        break;
      }
      case 5: { d_show = (theEvent.getController().getValue() == 1.0f) ? true : false; world.updateParam(g_show, d_show); refresh(); break; } // Show info
      case 6: { g_show = (theEvent.getController().getValue() == 1.0f) ? true : false; world.updateParam(g_show, d_show); refresh(); break; } // Show grid
      case 7: { room_min_size = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 8: { room_max_size = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 9: { corridor_num = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 10: { corridor_weight = PApplet.parseInt(theEvent.getController().getValue()); break; } 
      case 11: { turning_weight = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 12: { wall_fill = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 13: { generate_iter = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 14: { cleanup_iter = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 15: { min_room_num = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 16: { min_room_size = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 17: { max_rm_w = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 18: { max_rm_h = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 19: { max_corr_l = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 20: { obj_num = PApplet.parseInt(theEvent.getController().getValue()); break; }
      case 21: {
        g_layout = PApplet.parseInt(theEvent.getController().getValue());        
        if (g_layout == 0) {
          switch (room_type) {
            case 0: cp5.getController("Room").setLabel("Scattered"); break;
            case 1: cp5.getController("Room").setLabel("Sparse"); break;
            case 2: cp5.getController("Room").setLabel("Dense"); break;
            case 3: cp5.getController("Room").setLabel("Complex"); break;
          }
          cp5.getController("Room").unlock();
        }
        else {
          cp5.getController("Room").lock();
          cp5.getController("Room").setLabel("N/A");
        }
        if (g_layout == 2) {
          if (g_width < 5) {
            g_width = 5;
            cp5.getController("g_width").setValue(g_width);
          }
          if (g_height < 5) {
            g_height = 5;
            cp5.getController("g_width").setValue(g_height);
          }
        }
        break;
      }
      case 22: { room_type = PApplet.parseInt(theEvent.getController().getValue()); break; } // Choose room type
    }
  }
}

public void generate()
{
  world.generateWorld(g_layout + 1, g_width, g_height);
  refresh(); // Refresh screen
}

public void generate_random()
{
  world.randomWorld(); // Generate random world
  refresh(); // Refresh screen
}

public void refresh()
{
  // Position grid in center
  background(51);
  pushMatrix(); 
  translate(width*0.5f - g_width*0.5f*10 - 185*0.5f, height*0.5f - g_height*0.5f*10);
  renderGrid();
  popMatrix();
  renderInfo();
}

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  }
  else {
    println("User selected " + selection.getAbsolutePath());
    PrintWriter output;
    output = createWriter(selection + ".txt");
    for (int j = 0; j < world.grid_height; j++) {
      for (int i = 0; i < world.grid_width; i++) {
        output.print(world.grid[i][j] + " ");
      }
      output.print("\n");
    }
    output.flush(); // Writes the remaining data to the file
    output.close(); // Finishes the file 
  }
}
/* Procedural Content Generation
   Empty grid
   For testing pathfinding algorithms
   - This is really just an empty grid used for test purposes */

class PCG {
  byte[][] pcgrid; // Grid array
  int pcgrid_width; // Grid width
  int pcgrid_height; // Grid height
  
  PCG()
  {
  }
  
  public void updateParam(int g_width, int g_height)
  {
    pcgrid_width = g_width; // Get grid length
    pcgrid_height = g_height; // Get grid width
  }
  
  public void generatePCG(byte[][] g)
  {
    pcgrid = g; // Copy grid
  }
  
  public boolean bounded(int x, int y)
  {
    // Check if cell is inside grid
    if (x < 0 || x >= pcgrid_width || y < 0 || y >= pcgrid_height) return false;
    return true;
  }  
  
  public boolean blocked(int x, int y, int type)
  {
    // Check if cell is occupied
    if (bounded(x, y) && pcgrid[x][y] == type) return true;
    return false;
  }
}
/* Procedural Content Generation
   BSP Dungeon generation
   Based on BSP algorithm from RogueBasin
   http://roguebasin.roguelikedevelopment.org/index.php/Basic_BSP_Dungeon_generation */

class PCGBSP extends PCG {
  int room_num; // Minimum number of rooms
  int room_size; // Minimum size of rooms
  ArrayList rooms;
  
  PCGBSP()
  {
  }
  
  public void updateParam(int g_width, int g_height, int r_num, int r_size)
  {
    super.updateParam(g_width, g_height);
    // Room num
    if (r_num > (pcgrid_width*pcgrid_height)/50) r_num = (pcgrid_width*pcgrid_height)/50;
    room_num = r_num;
    
    // Min room size
    if (r_size > pcgrid_width*pcgrid_height) r_size = pcgrid_width*pcgrid_height;
    room_size = r_size;
  }
  
  public void generatePCGBSP(byte[][] g)
  {
    super.generatePCG(g); // Init grid 
    
    rooms = new ArrayList();
    BSPRoom root_room = new BSPRoom(0, 0, pcgrid_width, pcgrid_height, room_size);
    rooms.add(root_room); // Populate rectangle store with root area
    
    while (rooms.size() < room_num) { // Split the grid
      int split_index = PApplet.parseInt(random(rooms.size())); // Choose a random room to split
      BSPRoom split_room = (BSPRoom) rooms.get(split_index);
      if (split_room.splitBSP()) { // Attempt to split
        rooms.add(split_room.left_child);
        rooms.add(split_room.right_child);      
      } 
    }
    for (int n = 0; n < rooms.size(); n++) {
      // Go through each leaf node and create a room
      BSPRoom rm = (BSPRoom) rooms.get(n);
      
      if (rm.left_child != null || rm.right_child != null) continue; // If has child then go to next iteration
      
      rm.generateBSPRoom();
      
      for (int i = rm.bsp_x; i < rm.bsp_x + rm.bsp_width; i++) {
        pcgrid[i][rm.bsp_y] = 5;
        pcgrid[i][rm.bsp_y + rm.bsp_height - 1] = 5;
      }
      for (int j = rm.bsp_y; j < rm.bsp_y + rm.bsp_height; j++) {
        pcgrid[rm.bsp_x][j] = 5;
        pcgrid[rm.bsp_x + rm.bsp_width - 1][j] = 5;
      }
    }
    for (int n = 0; n < rooms.size(); n++) {
      // Go through each leaf node and create a room
      BSPRoom rm = (BSPRoom) rooms.get(n);
      
      if (rm.left_child != null || rm.right_child != null) continue; // If has child then go to next iteration
      
      // Horizontal walls
      for (int i = rm.room_x1; i <= rm.room_x2; i++) {
        pcgrid[i][rm.room_y1] = 2; // North wall
        pcgrid[i][rm.room_y2] = 2; // South wall
      }
      // Vertical walls
      for (int j = rm.room_y1; j <= rm.room_y2; j++) {
        pcgrid[rm.room_x1][j] = 2; // West wall
        pcgrid[rm.room_x2][j] = 2; // East wall
      }
        // Create room
        for (int j = rm.room_y1 + 1; j < rm.room_y2; j++) {
          for (int i = rm.room_x1 + 1; i < rm.room_x2; i++) {
              pcgrid[i][j] = 1; // Fill room
          }
        }
    }
    
    connectBSPRoom(root_room); // Connect room with corridors
  }

  public void connectBSPRoom(BSPRoom room)
  {
    // If has children, connect children first
    if (room.left_child != null) {
      connectBSPRoom(room.left_child);
      connectBSPRoom(room.right_child);
    }
    
    // If leaf node, stop
    if (room.left_child == null) return;
    
    // Connect rooms based on split direction
    if (room.horizontal) { // If split horizontally
      int c_x = room.bsp_x + room.bsp_width/2; // Node midpoint
      if (room.left_child.filled && room.right_child.filled) {
        // If both children are not split, create corridor from south wall of left child to north wall of right child
        int offset = checkCorner(c_x, -1,  room.left_child.room_y2, room.right_child.room_y1, room.horizontal);
        for (int j = room.left_child.room_y2; j <= room.right_child.room_y1; j++) {
          if (pcgrid[c_x + offset][j] == 1 || pcgrid[c_x + offset][j] == 4) break;
          else pcgrid[c_x + offset][j] = 4;
        }
      }
      else if (room.left_child.filled && !room.right_child.filled) {
        // If left child is not split, create corridor from south wall of left child to midpoint of right child
        int offset = checkCorner(c_x, -1,  room.left_child.room_y2, room.bsp_y + room.bsp_height - 1, room.horizontal);
        for (int j = room.left_child.room_y2; j < room.bsp_y + room.bsp_height; j++) {
          if (pcgrid[c_x + offset][j] == 1 || pcgrid[c_x + offset][j] == 4) break;
          else pcgrid[c_x + offset][j] = 4;
        }
      }
      else if (!room.left_child.filled && room.right_child.filled) {
        // If right child is not split, create corridor from north wall of right child to midpoint of left child
        int offset = checkCorner(c_x, -1, room.right_child.room_y1, room.bsp_y, room.horizontal);
        for (int j = room.right_child.room_y1; j >= room.bsp_y; j--) {
          if (pcgrid[c_x + offset][j] == 1 || pcgrid[c_x + offset][j] == 4) break;
          else pcgrid[c_x + offset][j] = 4;
        }
      }
      else {
        // If both children split, create corridor from midpoint of left child to midpoint of right child
        int offset = checkCorner(c_x, -1, room.left_child.bsp_height/2, room.left_child.bsp_height + room.right_child.bsp_height - 1, room.horizontal);
        for (int j = room.left_child.bsp_height/2; j < room.left_child.bsp_height + room.right_child.bsp_height; j++) {
          // Stop if we're in the second child and have reached a room tile or corridor tile
          if ((pcgrid[c_x + offset][j] == 1 || pcgrid[c_x + offset][j] == 4) && j > room.right_child.bsp_y) break;
          else pcgrid[c_x + offset][j] = 4;
        }
      }
    }
    else { // If split vertically
      int c_y = room.bsp_y + room.bsp_height/2; // Node midpoint
      if (room.left_child.filled && room.right_child.filled) {
        // If both children are not split, create corridor from right wall of left child to left wall of right child
        int offset = checkCorner(room.left_child.room_x2, room.right_child.room_x1, c_y, -1, room.horizontal);
        for (int i = room.left_child.room_x2; i <= room.right_child.room_x1; i++) {
          if (pcgrid[i][c_y + offset] == 1 || pcgrid[i][c_y + offset] == 4) break;
          else pcgrid[i][c_y + offset] = 4;
        }
      }
      else if (room.left_child.filled && !room.right_child.filled) {
        // If left child is not split, create corridor from right wall of left child to midpoint of right child
        int offset = checkCorner(room.left_child.room_x2, room.bsp_x + room.bsp_width - 1, c_y, -1, room.horizontal);
        for (int i = room.left_child.room_x2; i < room.bsp_x + room.bsp_width; i++) {
          if (pcgrid[i][c_y + offset] == 1 || pcgrid[i][c_y + offset] == 4) break;
          else pcgrid[i][c_y + offset] = 4;
        }
      }
      else if (!room.left_child.filled && room.right_child.filled) {
        // If right child is not split, create corridor from left wall of right child to midpoint of left child
        int offset = checkCorner(room.right_child.room_x1, room.left_child.bsp_x, c_y, -1, room.horizontal);
        for (int i = room.right_child.room_x1; i >= room.left_child.bsp_x; i--) {
          if (pcgrid[i][c_y + offset] == 1 || pcgrid[i][c_y + offset] == 4) break;
          else pcgrid[i][c_y + offset] = 4;
        }
      }
      else {
        // If both children split, create corridor from midpoint of left child to midpoint of right child
        int offset = checkCorner(room.left_child.bsp_width/2, room.left_child.bsp_width + room.right_child.bsp_width - 1, c_y, -1, room.horizontal);
        for (int i = room.left_child.bsp_width/2; i < room.left_child.bsp_width + room.right_child.bsp_width; i++) {
          // Stop if we're in the second child and have reached a room tile or corridor tile
          if ((pcgrid[i][c_y + offset] == 1 || pcgrid[i][c_y + offset] == 4) && i > room.right_child.bsp_x) break;
          else pcgrid[i][c_y + offset] = 4;
        }
      }
    }
  }
  
  public int checkCorner(int x1, int x2, int y1, int y2, boolean horizontal)
  {
    // Check if the corridor lands on a room corner
    if (horizontal) {
      if (pcgrid[x1][y1] == 2 && pcgrid[x1 + 1][y1] == 1) return 1; // Top right
      if (pcgrid[x1][y2] == 2 && pcgrid[x1 + 1][y2] == 1) return 1; // Bottom right
      if (pcgrid[x1][y1] == 2 && pcgrid[x1 - 1][y1] == 1) return -1; // Top left
      if (pcgrid[x1][y2] == 2 && pcgrid[x1 - 1][y2] == 1) return -1; // Bottom left
    }
    else {
      if (pcgrid[x1][y1] == 2 && pcgrid[x1][y1 + 1] == 1) return 1; // Bottom left
      if (pcgrid[x2][y1] == 2 && pcgrid[x2][y1 + 1] == 1) return 1; // Bottom right
      if (pcgrid[x1][y1] == 2 && pcgrid[x1][y1 - 1] == 1) return -1; // Top left
      if (pcgrid[x2][y1] == 2 && pcgrid[x2][y1 - 1] == 1) return -1; // Top right
    }
    return 0;      
  }
}

class BSPRoom {
  int min_size; // Default should be 5
  int bsp_x;
  int bsp_y;
  int bsp_width;
  int bsp_height;
  int room_x1;
  int room_y1;
  int room_x2;
  int room_y2;
  boolean filled = false;
  boolean horizontal; // Direction of split
  BSPRoom left_child;
  BSPRoom right_child;
  
  BSPRoom(int x, int y, int w, int h, int r_size)
  {
    bsp_x = x;
    bsp_y = y;
    bsp_width = w;
    bsp_height = h;
    min_size = r_size;
  }
  
  public boolean splitBSP()
  {    
    if (left_child != null) return false; // If already split, bail out
        
    if (PApplet.parseInt(random(100)) > 50) horizontal = true;
    else horizontal = false;
    
    int max_size = (horizontal ? bsp_height : bsp_width) - min_size; // Maximum height/width we can split off
    if (max_size <= min_size) return false; // Area too small to split, bail out
        
    int split_point = PApplet.parseInt(random(max_size)); // generate split point 
    if(split_point < min_size) split_point = min_size; // Adjust split point so there's at least min_size in both partitions
        
    if (horizontal) { // Populate child areas
        left_child = new BSPRoom(bsp_x, bsp_y, bsp_width, split_point, min_size); 
        right_child = new BSPRoom(bsp_x, bsp_y + split_point, bsp_width, bsp_height - split_point, min_size);
    }
    else {
        left_child = new BSPRoom(bsp_x, bsp_y, split_point, bsp_height, min_size);
        right_child = new BSPRoom(bsp_x + split_point, bsp_y, bsp_width - split_point, bsp_height, min_size);
    }
    return true; // Split successful
  }

  public void generateBSPRoom()
  {
    if (left_child == null) { // If leaf node, create a dungeon within the minimum size constraints
      int min_x = max(bsp_width*3/4, min_size);
      int min_y = max(bsp_height*3/4, min_size);
      room_x1 = bsp_x + ((bsp_width - min_size <= 0) ? 0 : PApplet.parseInt(random(bsp_width - min_x)));
      room_y1 = bsp_y + ((bsp_height - min_size <= 0) ? 0 : PApplet.parseInt(random(bsp_height - min_y)));
      room_x2 = room_x1 + max(PApplet.parseInt(random(bsp_width - room_x1)), min_x) - 1;
      room_y2 = room_y1 + max(PApplet.parseInt(random(bsp_height - room_y1)), min_y) - 1;
      filled = true;
    }
  }
}
/* Procedural Content Generation
   Basic
   Random room placement
   - This algorithm places random rooms in the grid, then connects them with
     corridors using A* pathfinding algorithm */

class PCGBasic extends PCG {
  int layout_type; // Layout type
  int room_type; // Room type
  int room_max; // Max room size
  int room_min; // Min room size
  int room_num; // Number of rooms
  int room_base;
  int room_radix;
  boolean room_blocked = false; // If room is blocked
  int redo = 1000; // Recursion limit
  ArrayList rooms; // Room arraylist
  int corridor_num;
  int corridor_weight;
  int turning_weight;

  PCGBasic()
  {
  }

  public void updateParam(int g_width, int g_height, int r_type, int r_min, int r_max, int c_num, int c_weight, int t_weight)
  {
    super.updateParam(g_width, g_height);
    room_type = r_type; // Room type
    
    room_min = r_min; // Default 9
    room_max = r_max; // Default 16
    room_base = PApplet.parseInt((room_min + 1)*0.5f);
    room_radix = PApplet.parseInt((room_max - room_min)*0.5f + 1);
    
    switch(room_type) {
      case 0: room_num = (pcgrid_width*pcgrid_height)/PApplet.parseInt(random(room_min, room_max)*room_max) + 1;
              break; // Scattered
      case 1: room_num = (pcgrid_width*pcgrid_height)/PApplet.parseInt(random(room_min, room_max)*room_max*2) + 1;
              break; // Sparse
      case 2: room_num = (pcgrid_width*pcgrid_height)/PApplet.parseInt(random(room_min, room_max)*room_min*0.5f) + 1;
              break; // Dense
      default: room_num = (pcgrid_width*pcgrid_height)/PApplet.parseInt(random(room_min, room_max)*room_max) + 1;
              break; // Scattered
    }
    
    corridor_num = c_num;
    corridor_weight = c_weight;
    turning_weight = t_weight;
  }

  public void generatePCGBasic(byte[][] g)
  {
    super.generatePCG(g); // Init grid 
    
    initRooms(); // Initialize rooms
    initCorridors(); // Initialize corridors
  }
  
  public void initRooms()
  {
    rooms = new ArrayList(); // New room arraylist
    for (int n = 0; n < room_num; n++) {
      room_blocked = false; // Unblock
      Room rm = new Room(pcgrid_width, pcgrid_height, room_base, room_radix, corridor_num); // Create new room
      room_blocked = blockRoom(rm); // Check if room is blocked
            
      if (room_blocked) {
        n--; // Remake room
        redo--; // Stops if taking too long
        if (redo == 0) {
          room_num--;
          redo = 1000; // Recursion limit
        }
      }
      else {
        rooms.add(rm);
        // Create room
        for (int j = rm.room_y1; j <= rm.room_y2; j++) {
          for (int i = rm.room_x1; i <= rm.room_x2; i++) {
              pcgrid[i][j] = 1;
          }
        }
        // Create room walls
        for (int i = rm.wall_x1; i <= rm.wall_x2; i++) {
          if (pcgrid[i][rm.wall_y1] != 1) pcgrid[i][rm.wall_y1] = 2;
          if (pcgrid[i][rm.wall_y2] != 1) pcgrid[i][rm.wall_y2] = 2;
        }
        for (int j = rm.wall_y1; j <= rm.wall_y2; j++) {
          if (pcgrid[rm.wall_x1][j] != 1) pcgrid[rm.wall_x1][j] = 2;
          if (pcgrid[rm.wall_x2][j] != 1) pcgrid[rm.wall_x2][j] = 2;
        }
        // Place openings
        for (int k = 0; k < rm.opening_num; k++) {
          if (pcgrid[rm.opening[k][0]][rm.opening[k][1]] != 1) pcgrid[rm.opening[k][0]][rm.opening[k][1]] = 3;
        }
      }
    }
  }
  
  public boolean blockRoom(Room rm)
  {
    // If outside of grid
    if (!bounded(rm.wall_x1, rm.wall_y1) || !bounded(rm.wall_x2, rm.wall_y1) ||
        !bounded(rm.wall_x1, rm.wall_y2) || !bounded(rm.wall_x2, rm.wall_y2)) {
        return true;
    }
    // If blocked by another room
    if (room_type != 3) {
      for (int i = rm.wall_x1 - 1; i < rm.wall_x2 + 1; i++) {
        // Check upper and lower bound
        if (bounded(i, rm.wall_y1 - 1) && !blocked(i, rm.wall_y1 - 1, 0)) return true;
        if (bounded(i, rm.wall_y2 + 1) && !blocked(i, rm.wall_y2 + 1, 0)) return true;
      }
      for (int j = rm.wall_y1 - 1; j < rm.wall_y2 + 1; j++) {
        // Check left and right bound
        if (bounded(rm.wall_x1 - 1, j) && !blocked(rm.wall_x1 - 1, j, 0)) return true;
        if (bounded(rm.wall_x2 + 1, j) && !blocked(rm.wall_x2 + 1, j, 0)) return true;
      }
    }
    return false;
  }
  
  public void initCorridors()
  {
    if (room_type != 3) {
      for (int i = 0; i < rooms.size(); i++) {
        // Go through each room and connect its first opening to the first opening of the next room
        Room rm1 = (Room) rooms.get(i);
        Room rm2;
        if (i == rooms.size() - 1) rm2 = (Room) rooms.get(0);
        else rm2 = (Room) rooms.get(i + 1); // If not last room
        
        // Connect rooms
        basicAStar(pcgrid, rm1.opening[0][0], rm1.opening[0][1], rm2.opening[0][0], rm2.opening[0][1], corridor_weight, turning_weight);
        
        // Random tunneling
        for (int j = 1; j < rm1.opening_num; j++) {
          tunnelRandom(rm1.opening[j][0], rm1.opening[j][1], rm1.opening[j][2], 3);
        }
      }
    }
    else { // If complex
      Room rm1 = (Room) rooms.get(0);
      for (int i = 1; i < rooms.size(); i++) {
        // Go through each room and connect its first opening to the first opening of the first room
        Room rm2 = (Room) rooms.get(i);
        // Connect rooms
        basicAStar(pcgrid, rm1.opening[0][0], rm1.opening[0][1], rm2.opening[0][0], rm2.opening[0][1], corridor_weight, turning_weight);
      }        
      // Random tunneling
      for (int i = 0; i < rooms.size(); i++) {
        Room rm3 = (Room) rooms.get(i);
        for (int j = 1; j < rm3.opening_num; j++) {
          tunnelRandom(rm3.opening[j][0], rm3.opening[j][1], rm3.opening[j][2], 3);
        }
      }
    }
  }
  public void tunnelRandom(int x, int y, int dir, int iteration)
  {
    if (iteration == 0) return; // End of recursion iteration
    
    // Choose a random direction and check to see if that cell is occupied, if not, head in that direction
    switch (dir) {
      case 0: if (!blockCorridor(x, y - 1, 0)) tunnel(x, y - 1, dir); // North
              else tunnelRandom(x, y, shuffleDir(dir, 0), iteration - 1); // Try again
              break;
      case 1: if (!blockCorridor(x + 1, y, 1)) tunnel(x + 1, y, dir); // East
              else tunnelRandom(x, y, shuffleDir(dir, 0), iteration - 1); // Try again
              break;
      case 2: if (!blockCorridor(x, y + 1, 0)) tunnel(x, y + 1, dir); // South
              else tunnelRandom(x, y, shuffleDir(dir, 0), iteration - 1); // Try again
              break;
      case 3: if (!blockCorridor(x - 1, y, 1)) tunnel(x - 1, y, dir); // West
              else tunnelRandom(x, y, shuffleDir(dir, 0), iteration - 1); // Try again
              break;
    }
  }
  
  public void tunnel(int x, int y, int dir)
  {
    if (pcgrid[x][y] == 2 || pcgrid[x][y] == 3) pcgrid[x][y] = 3; // If on top of wall or door
    else {
      pcgrid[x][y] = 4; // Set cell to corridor
      tunnelRandom(x, y, shuffleDir(dir, 85), 3); // Randomly choose next cell to go to
    }
  }
  
  public int shuffleDir(int dir, int prob)
  {
    // Randomly choose direction based on probability
    if (PApplet.parseInt(random(100)) > (100 - prob)) {
      return dir; // Stay same direction
    }
    else { // Change direction
      switch (dir) {
        case 0: if (PApplet.parseInt(random(100)) < 50) return 1; // East
                if (PApplet.parseInt(random(100)) >= 50) return 3; // West
                break;
        case 1: if (PApplet.parseInt(random(100)) < 50) return 0; // North
                if (PApplet.parseInt(random(100)) >= 50) return 2; // South
                break;
        case 2: if (PApplet.parseInt(random(100)) < 50) return 1; // East
                if (PApplet.parseInt(random(100)) >= 50) return 3; // West
                break;
        case 3: if (PApplet.parseInt(random(100)) < 50) return 0; // North
                if (PApplet.parseInt(random(100)) >= 50) return 2; // South
                break;     
      }
    }
    return dir;
  }
  
  public boolean blockCorridor(int x, int y, int orientation)
  {
    if (!bounded(x, y)) return true; // If outside of grid
    
    // Check if current cell is available as corridor based on previous corridor cell location
    switch (orientation) {
       // N/S
      case 0: if (blocked(x, y, 1) || // Blocked by room
                  (blocked(x - 1, y, 4) && blocked(x - 1, y + 1, 4)) || // Next to corridor
                  (blocked(x - 1, y, 4) && blocked(x - 1, y - 1, 4)) || // Next to corridor
                  (blocked(x + 1, y, 4) && blocked(x + 1, y + 1, 4)) || // Next to corridor
                  (blocked(x + 1, y, 4) && blocked(x + 1, y - 1, 4)) || // Next to corridor
                  ((blocked(x, y, 2) || blocked(x, y, 3)) && (((blocked(x, y - 1, 2) || blocked(x, y - 1, 3)) && (blocked(x + 1, y, 2) || blocked(x + 1, y, 2))) ||
                                                             ((blocked(x, y - 1, 2) || blocked(x, y - 1, 3)) && (blocked(x - 1, y, 2) || blocked(x - 1, y, 2))) ||
                                                             ((blocked(x, y + 1, 2) || blocked(x, y + 1, 3)) && (blocked(x + 1, y, 2) || blocked(x + 1, y, 2))) ||
                                                             ((blocked(x, y + 1, 2) || blocked(x, y + 1, 3)) && (blocked(x - 1, y, 2) || blocked(x - 1, y, 2))))))
                  return true;
              break;
      // W/E
      case 1: if (blocked(x, y, 1) || // Blocked by room
                  (blocked(x, y - 1, 4) && blocked(x - 1, y + 1, 4)) || // Next to corridor
                  (blocked(x, y - 1, 4) && blocked(x - 1, y - 1, 4)) || // Next to corridor
                  (blocked(x, y + 1, 4) && blocked(x + 1, y + 1, 4)) || // Next to corridor
                  (blocked(x, y + 1, 4) && blocked(x + 1, y - 1, 4)) || // Next to corridor
                  ((blocked(x, y, 2) || blocked(x, y, 3)) && (((blocked(x, y - 1, 2) || blocked(x, y - 1, 3)) && (blocked(x + 1, y, 2) || blocked(x + 1, y, 2))) ||
                                                             ((blocked(x, y - 1, 2) || blocked(x, y - 1, 3)) && (blocked(x - 1, y, 2) || blocked(x - 1, y, 2))) ||
                                                             ((blocked(x, y + 1, 2) || blocked(x, y + 1, 3)) && (blocked(x + 1, y, 2) || blocked(x + 1, y, 2))) ||
                                                             ((blocked(x, y + 1, 2) || blocked(x, y + 1, 3)) && (blocked(x - 1, y, 2) || blocked(x - 1, y, 2))))))
                  return true;
              break;  
    }
    
    return false;    
  }
}

class Room {
  int pcgrid_width;
  int pcgrid_height;
  int room_x;
  int room_y;
  int room_width;
  int room_height;
  int room_x1;
  int room_x2;
  int room_y1;
  int room_y2;
  int wall_x1;
  int wall_x2;
  int wall_y1;
  int wall_y2;
  int[][] opening; // Doors
  int opening_num; // Number of doors
  
  Room(int w, int h, int base, int radix, int c_num)
  {
    pcgrid_width = w;
    pcgrid_height = h;
    room_width = PApplet.parseInt(random(radix) + base);
    room_height = PApplet.parseInt(random(radix) + base);
    room_x1 = PApplet.parseInt(random(0, (pcgrid_width - room_width)));
    room_y1 = PApplet.parseInt(random(0, (pcgrid_height - room_height)));
    room_x2 = room_x1 + room_width - 1;
    room_y2 = room_y1 + room_height - 1;
    room_x = room_x1 + PApplet.parseInt((room_x2 - room_x1)*0.5f);
    room_y = room_y1 + PApplet.parseInt((room_y2 - room_y1)*0.5f);
    wall_x1 = room_x1 - 1;
    wall_x2 = room_x2 + 1;
    wall_y1 = room_y1 - 1;
    wall_y2 = room_y2 + 1;
    opening_num = PApplet.parseInt(random(1, c_num + 1)); // Open up doorway
    opening = new int[opening_num][3];
    initDoors();
  }
  
  public void initDoors()
  {
    int count = opening_num;
    while (count != 0) {
      opening[count - 1][2] = PApplet.parseInt(random(0, 4)); // Door orientation
      // Make sure door is not on corner or facing wall
      switch (opening[count - 1][2]) {
        case 0: // North wall
                int x1 = PApplet.parseInt(random(wall_x1, wall_x2));
                if (x1 != wall_x1 && x1 != wall_x2 && wall_y1 >= 1) {
                  opening[count - 1][0] = x1;
                  opening[count - 1][1] = wall_y1;
                  opening[count - 1][2] = 0;
                  count--;
                }
                break;
        case 1: // East wall
                int y2 = PApplet.parseInt(random(wall_y1, wall_y2));
                if (y2 != wall_y1 && y2 != wall_y2 && wall_x2 < pcgrid_width - 1) {
                  opening[count - 1][0] = wall_x2;
                  opening[count - 1][1] = y2;
                  opening[count - 1][2] = 1;
                  count--;
                }
                break;
        case 2: // South wall
                int x2 = PApplet.parseInt(random(wall_x1, wall_x2));
                if (x2 != wall_x1 && x2 != wall_x2 && wall_y2 < pcgrid_height - 1) {
                  opening[count - 1][0] = x2;
                  opening[count - 1][1] = wall_y2;
                  opening[count - 1][2] = 2;
                  count--;
                }
                break;
        case 3: // West wall
                int y1 = PApplet.parseInt(random(wall_y1, wall_y2));
                if (y1 != wall_y1 && y1 != wall_y2 && wall_x1 >= 1) {
                  opening[count - 1][0] = wall_x1;
                  opening[count - 1][1] = y1;
                  opening[count - 1][2] = 3;
                  count--;
                }
                break;
      }
    }
  }
}

BinaryHeap open_list;
BinaryHeap closed_list;

public void basicAStar(byte[][] pcgrid, int x1, int y1, int x2, int y2, int corr_wt, int trn_wt)
{
  int grid_w = pcgrid.length;
  int grid_h = pcgrid[0].length;
  byte[][][] grid = new byte[grid_w][grid_h][3];
  for (int j = 0; j < grid_h; j++) {
    for (int i = 0; i < grid_w; i++) {
      grid[i][j][0] = pcgrid[i][j]; // Cell content
      grid[i][j][1] = 0; // Open list
      grid[i][j][2] = 0; // Closed list
    }
  }
    
  open_list = new BinaryHeap();
  closed_list = new BinaryHeap();
  
  // Push starting node into open list
  Node start = new Node(x1, y1, 0, 0, -1);
  Node end = new Node(0, 0, 0, 0, -1);
  open_list.insert(start);
  
  // While open list is not empty
  while (open_list.getSize() > 0) {
    Node current = (Node) open_list.remove(0); // Remove from open list
    grid[current.x][current.y][1] = 0;
    
    // If at goal
    if (current.x == x2 && current.y == y2) {
      while (current.x != x1 || current.y != y1) {
        if (grid[current.x][current.y][0] == 3) grid[current.x][current.y][0] = 3;
        else grid[current.x][current.y][0] = 4;
        current = (Node) current.parent;
      }
      break;
    }
    
    // Process neighbors
    neighbor(grid, current, current.x, current.y - 1, x2, y2, 0, corr_wt, trn_wt);
    neighbor(grid, current, current.x + 1, current.y, x2, y2, 1, corr_wt, trn_wt);
    neighbor(grid, current, current.x, current.y + 1, x2, y2, 2, corr_wt, trn_wt);
    neighbor(grid, current, current.x - 1, current.y, x2, y2, 3, corr_wt, trn_wt);
    
    closed_list.insert(current); // Add to closed list
    grid[current.x][current.y][2] = 1;
  }
  
  // Update grid
  for (int j = 0; j < grid_h; j++) {
    for (int i = 0; i < grid_w; i++) {
      pcgrid[i][j] = grid[i][j][0];
    }
  }
}

public void neighbor(byte[][][] grid, Node current, int x, int y, int x2, int y2, int dir, int corr_wt, int trn_wt)
{
  // If not blocked or not in closed list
  if (!AStarBlocked(grid, x, y) && grid[x][y][2] != 1) {
    if (grid[x][y][1] != 1) { // If not in open list
      int g_score = current.g + 10; // Calculate g score
      if (grid[x][y][0] == 4) g_score = g_score - corr_wt; // Added weight for joining corridors
      if (dir == current.dir) g_score = g_score - trn_wt; // Added weight for keep straight
      int h_score = heuristic(x, y, x2, y2, 0); // Calculate h score
      Node child = new Node(x, y, g_score, h_score, dir);
      child.parent = current; // Assign parent
      open_list.insert(child); // Add to open list
      grid[x][y][1] = 1;
    }
    else { // If already in open list
      int pos = open_list.find(x, y);
      //Node temp = open_list.remove(pos);
      Node temp = (Node) open_list.h.get(pos);
      // If has better score
      if (current.g + 10 < temp.g || (grid[x][y][0] == 4 && current.g + (10 - corr_wt) < temp.g) || (temp.dir == current.dir && current.g + (10 - trn_wt) < temp.g)) {
        temp.g = current.g + 10; // Set new g score
        if (grid[x][y][0] == 4) temp.g = temp.g - corr_wt; // Added weight for joining corridors
        if (temp.dir == current.dir) temp.g = temp.g - trn_wt; // Added weight for keep straight
        temp.f = temp.g + temp.h; // Calculate new f score
        temp.parent = current; // Assign new parent
        open_list.moveUp(pos);
      }
      // Insert back to open list
      //open_list.insert(temp);
    }
  }  
}

public int heuristic(int x, int y, int x2, int y2, int method)
{
  int h_score = 0;
  switch (method) {
    case 0: h_score = 10*(abs(x - x2) + abs(y - y2));
            break; // Manhattan
    case 1: int xDistance = abs(x - x2);
            int yDistance = abs(y - y2);
            if (xDistance > yDistance) h_score = 14*yDistance + 10*(xDistance - yDistance);
            else h_score = 14*xDistance + 10*(yDistance - xDistance);
            break; // Diagonal
  }
  return h_score;
}

public boolean AStarBlocked(byte[][][] grid, int x, int y)
{
  if (x < 0 || x >= grid.length || y < 0 || y >= grid[0].length) return true; // Check if cell is inside grid
  if (grid[x][y][0] == 1) return true; // Check if cell is occupied by room
  if (grid[x][y][0] == 2) return true; // Check if cell is occupied by corridor
  return false;
}

class Node {
  int x;
  int y;
  int f;
  int g;
  int h;
  int dir;
  Node parent;
  
  Node(int xpos, int ypos, int gscore, int hscore, int direction)
  {
    x = xpos;
    y = ypos;
    g = gscore;
    h = hscore;
    f = g + h;
    dir = direction;
  }
}

class BinaryHeap {
  ArrayList h;

  BinaryHeap()
  {
    h = new ArrayList();
  }

  public void insert(Node n)
  {
    h.add(n);
    moveUp(h.size() - 1);
  }
  
  public Node remove(int pos)
  {
    Node n = (Node) h.get(pos);
    Node last = (Node) h.remove(h.size() - 1);
    if (pos == h.size()) return last;
    if (!h.isEmpty()) {
      h.set(pos, last);
      heapify(pos);
    }
    return n;
  }
  
  public void heapify(int pos)
  {
    while (pos < h.size()/2) {
      int child = 2*pos + 1;
      Node n = (Node) h.get(pos);
      Node nc = (Node) h.get(child);
      Node nc2;
      if (child < h.size() - 1) {
        nc2 = (Node) h.get(child + 1);
        if (nc.f > nc2.f) child++;
        nc = (Node) h.get(child);
      }
      if (n.f <= nc.f) break;
      Node tmp = (Node) h.get(pos);
      h.set(pos, (Node) h.get(child));
      h.set(child, tmp);
      pos = child;
    }
  }
  
  public void moveUp(int pos)
  {
    while (pos > 0) {
      int parent = (pos - 1)/2;
      Node n = (Node) h.get(pos);
      Node np = (Node) h.get(parent);
      if (n.f >= np.f) break;
      Node tmp = (Node) h.get(pos);
      h.set(pos, (Node) h.get(parent));
      h.set(parent, tmp);
      pos = parent;
    }
  }
  
  public int find(int x, int y)
  {
    for (int i = 0; i < h.size(); i++) {
      Node n = (Node) h.get(i);
      if (n.x == x && n.y == y) return i;
    }
    return -1;
  }
  
  public int getSize()
  {
    return h.size(); 
  }
}
/* Procedural Content Generation
   Build Dungeon generation
   Based on algorithm from RogueBasin by Mike Anderson
   http://roguebasin.roguelikedevelopment.org/index.php?title=Dungeon-Building_Algorithm
   Java version by Solarnus and Processing version by Ted Brown
   - The original code tended to create rooms connected to rooms with dead end corridors sticking out,
     this version is modified to reduce the number of dead ends and increase the likelihood of a room
     being generated at the end of a corridor
   - This algorithm is implemented to test the extensibility of the dungeon generator, efforts were made
     to retain as much of the original code as possible */

class PCGBuild extends PCG {
  int max_rm_w;
  int max_rm_h;
  int max_corr_l;
  int obj_num;
  boolean corr_room = false;
  
  PCGBuild()
  {
  }
  
  public void updateParam(int g_width, int g_height, int m_roomw, int m_roomh, int m_corrl, int o_num)
  {
    super.updateParam(g_width, g_height);
    max_rm_w = m_roomw;
    max_rm_h = m_roomh;
    max_corr_l = m_corrl;
    obj_num = o_num;
  }

  public void generatePCGBuild(byte[][] g)
  {
    super.generatePCG(g); // Init grid

    // Calls the dungeon creation code
    createDungeon(pcgrid_width, pcgrid_height, obj_num);
    
    for (int y = 0; y < pcgrid_height; y++) {
      for (int x = 0; x < pcgrid_width; x++) {
        switch(getCell(x, y)) {
          case tileUnused: pcgrid[x][y] = 0; break;
          case tileDirtWall: pcgrid[x][y] = 2; break;
          case tileDirtFloor: pcgrid[x][y] = 1; break;
          case tileStoneWall: pcgrid[x][y] = 2; break;
          case tileCorridor: pcgrid[x][y] = 4; break;
          case tileDoor: pcgrid[x][y] = 3; break;
        }
      }
    }
  }

  //size of the map
  private int xsize = 0;
  private int ysize = 0;

  //number of "objects" to generate on the map
  private int objects = 0;

  //define the %chance to generate either a room or a corridor on the map
  //BTW, rooms are 1st priority so actually it's enough to just define the chance of generating a room
  private int chanceRoom = 50; 
  private int chanceCorridor = 50;

  //our map
  private int[] dungeon_map = {};

  //the old seed from the RNG is saved in this one
  private long oldseed = 0;

  //a list over tile types we're using
  final private int tileUnused = 0;
  final private int tileDirtWall = 1; //not in use
  final private int tileDirtFloor = 2;
  final private int tileStoneWall = 3;
  final private int tileCorridor = 4;
  final private int tileDoor = 5;
  final private int tileUpStairs = 6;
  final private int tileDownStairs = 7;
  final private int tileChest = 8;

  //misc. messages to print
  private String msgXSize = "X size of dungeon: \t";
  private String msgYSize = "Y size of dungeon: \t";
  private String msgMaxObjects = "max # of objects: \t";
  private String msgNumObjects = "# of objects made: \t";
  private String msgHelp = "";
  private String msgDetailedHelp = "";

  public void createDungeon(int inx, int iny, int inobj) {
  /*******************************************************************************/
    // Here's the one generating the whole map
    if (inobj < 1) objects = 10;
    else objects = inobj;

    // Adjust the size of the map if it's too small
    if (inx < 3) xsize = 3;
    else xsize = inx;

    if (iny < 3) ysize = 3;
    else ysize = iny;
    
    //System.out.println(msgXSize + xsize);
    //System.out.println(msgYSize + ysize);
    //System.out.println(msgMaxObjects + objects);

    //redefine the map var, so it's adjusted to our new map size
    dungeon_map = new int[xsize * ysize];

    //start with making the "standard stuff" on the map
    for (int y = 0; y < ysize; y++) {
      for (int x = 0; x < xsize; x++) {
        //ie, making the borders of unwalkable walls
        if (y == 0) setCell(x, y, tileStoneWall);
        else if (y == ysize-1) setCell(x, y, tileStoneWall);
        else if (x == 0) setCell(x, y, tileStoneWall);
        else if (x == xsize-1) setCell(x, y, tileStoneWall);

        //and fill the rest with dirt
        else setCell(x, y, tileUnused);
      }
    }

    /*******************************************************************************
     
    And now the code of the random-map-generation-algorithm begins!
     
    *******************************************************************************/

    //start with making a room in the middle, which we can start building upon
    makeRoom(xsize/2, ysize/2, max_rm_w, max_rm_h, getRand(0,3));

    //keep count of the number of "objects" we've made
    int currentFeatures = 1; //+1 for the first room we just made

    //then we start the main loop
    for (int countingTries = 0; countingTries < 1000; countingTries++) {

      //check if we've reached our quota
      if (currentFeatures == objects) {
        break;
      }

      //start with a random wall
      int newx = 0;
      int xmod = 0;
      int newy = 0;
      int ymod = 0;
      int validTile = -1;

      //1000 chances to find a suitable object (room or corridor)..
      //(yea, i know it's kinda ugly with a for-loop... -_-')

      for (int testing = 0; testing < 1000; testing++) {
        newx = getRand(1, xsize-1);
        newy = getRand(1, ysize-1);
        validTile = -1;

        //System.out.println("tempx: " + newx + "\ttempy: " + newy);

        if (getCell(newx, newy) == tileDirtWall || getCell(newx, newy) == tileCorridor) {
          //check if we can reach the place
          if (getCell(newx, newy+1) == tileDirtFloor || getCell(newx, newy+1) == tileCorridor) {
            validTile = 0; //
            xmod = 0;
            ymod = -1;
          }
          else if (getCell(newx-1, newy) == tileDirtFloor || getCell(newx-1, newy) == tileCorridor) {
            validTile = 1; //
            xmod = +1;
            ymod = 0;
          }

          else if (getCell(newx, newy-1) == tileDirtFloor || getCell(newx, newy-1) == tileCorridor) {
            validTile = 2; //
            xmod = 0;
            ymod = +1;
          }

          else if (getCell(newx+1, newy) == tileDirtFloor || getCell(newx+1, newy) == tileCorridor) {
            validTile = 3; //
            xmod = -1;
            ymod = 0;
          }

          //check that we haven't got another door nearby, so we won't get alot of openings besides each other

          if (validTile > -1) {
            if (getCell(newx, newy+1) == tileDoor) //north
              validTile = -1;
            else if (getCell(newx-1, newy) == tileDoor)//east
              validTile = -1;
            else if (getCell(newx, newy-1) == tileDoor)//south
              validTile = -1;
            else if (getCell(newx+1, newy) == tileDoor)//west
              validTile = -1;
          }

          //if we can, jump out of the loop and continue with the rest
          if (validTile > -1) break;
        }
      }

      if (validTile > -1) {

        //choose what to build now at our newly found place, and at what direction
        int feature = getRand(0, 100);
        if (feature <= chanceRoom) { //a new room
            if (makeRoom((newx+xmod), (newy+ymod), max_rm_w, max_rm_h, validTile)) {
            currentFeatures++; //add to our quota

            //then we mark the wall opening with a door
            setCell(newx, newy, tileDoor);

            //clean up infront of the door so we can reach it
            setCell((newx+xmod), (newy+ymod), tileDirtFloor);
          }
        }

        else if (feature >= chanceRoom) { //new corridor
          if (makeCorridor((newx+xmod), (newy+ymod), max_corr_l, validTile)) {
            //same thing here, add to the quota and a door
            currentFeatures++;
            if (corr_room) {
              currentFeatures++;
              corr_room = false;
            }
            setCell(newx, newy, tileDoor);
          }
        }
      }
    }
    //all done with the map generation, tell the user about it and finish
    //System.out.println(msgNumObjects + currentFeatures);
  }

  //setting a tile's type
  private void setCell(int x, int y, int celltype) {
    dungeon_map[x + xsize * y] = celltype;
  }

  //returns the type of a tile
  private int getCell(int x, int y) {
    return dungeon_map[x + xsize * y];
  }

  //The RNG. the seed is based on seconds from the "java epoch" ( I think..)
  //perhaps it's the same date as the unix epoch
  //Update:Java Date/Random have been removed in favor of Processing's own random()
  private int getRand(int min, int max) {
    long seed = (int)random(1000) + oldseed;
    oldseed = seed;
    
    int n = max - min + 1;
    int i = (int)random(n);
    if (i < 0) i = -i;

    //System.out.println("seed: " + seed + "\tnum:  " + (min + i));
    return min + i;
  }


  private boolean makeCorridor(int x, int y, int lenght, int direction) {
  /*******************************************************************************/
    //define the dimensions of the corridor (er.. only the width and height..)
    int len = getRand(2, lenght);
    int floor = tileCorridor;
    int dir = 0;
    if (direction > 0 && direction < 4) dir = direction;

    int xtemp = 0;
    int ytemp = 0;

    // reject corridors that are out of bounds
    if (x < 0 || x > xsize) return false;
    if (y < 0 || y > ysize) return false;
    
    switch(dir) {
      
      case 0: //north
        xtemp = x;
  
        // make sure it's not out of the boundaries
        for (ytemp = y; ytemp > (y-len); ytemp--) {
          if (ytemp < 0 || ytemp > ysize) return false; //oh boho, it was!
          if (getCell(xtemp, ytemp) != tileUnused) return false;
        }
  
        //if we're still here, let's start building
        for (ytemp = y; ytemp > (y-len); ytemp--) {
          setCell(xtemp, ytemp, floor);
        }
        break;

      case 1: //east
        ytemp = y;
  
        for (xtemp = x; xtemp < (x+len); xtemp++) {
          if (xtemp < 0 || xtemp > xsize) return false;
          if (getCell(xtemp, ytemp) != tileUnused) return false;
        }
  
        for (xtemp = x; xtemp < (x+len); xtemp++) {
          setCell(xtemp, ytemp, floor);
        }
        break;
  
      case 2: // south
        xtemp = x;
  
        for (ytemp = y; ytemp < (y+len); ytemp++) {
          if (ytemp < 0 || ytemp > ysize) return false;
          if (getCell(xtemp, ytemp) != tileUnused) return false;
        }
  
        for (ytemp = y; ytemp < (y+len); ytemp++) {
          setCell(xtemp, ytemp, floor);
        }
        break;
  
      case 3: // west
        ytemp = y;
  
        for (xtemp = x; xtemp > (x-len); xtemp--) {
          if (xtemp < 0 || xtemp > xsize) return false;
          if (getCell(xtemp, ytemp) != tileUnused) return false;
        }
  
        for (xtemp = x; xtemp > (x-len); xtemp--) {
          setCell(xtemp, ytemp, floor);
        }
        break;
      }

      if (makeRoom(xtemp, ytemp, max_rm_w, max_rm_h, direction)) {
        corr_room = true;

        //then we mark the wall opening with a door
        setCell(xtemp, ytemp, tileDoor);

        //clean up infront of the door so we can reach it
        //setCell(xtemp, ytemp, tileDirtFloor);
      }

    //woot, we're still here! let's tell the other guys we're done!!
    return true;
  }


  
  private boolean makeRoom(int x, int y, int xlength, int ylength, int direction) {
  /*******************************************************************************/

    //define the dimensions of the room, it should be at least 4x4 tiles (2x2 for walking on, the rest is walls)
    int xlen = getRand(4, xlength);
    int ylen = getRand(4, ylength);

    //the tile type it's going to be filled with
    int floor = tileDirtFloor; //jordgolv..
    int wall = tileDirtWall; //jordv????gg

    //choose the way it's pointing at
    int dir = 0;
    if (direction > 0 && direction < 4) dir = direction;

    switch(dir) {

      case 0: // north
  
        //Check if there's enough space left for it
        for (int ytemp = y; ytemp > (y-ylen); ytemp--) {
          if (ytemp < 0 || ytemp > ysize) return false;
          for (int xtemp = (x-xlen/2); xtemp < (x+(xlen+1)/2); xtemp++) {
            if (xtemp < 0 || xtemp > xsize) return false;
            if (getCell(xtemp, ytemp) != tileUnused) return false; //no space left...
          }
        }
  
        //we're still here, build
        for (int ytemp = y; ytemp > (y-ylen); ytemp--) {
          for (int xtemp = (x-xlen/2); xtemp < (x+(xlen+1)/2); xtemp++) {
            //start with the walls
            if (xtemp == (x-xlen/2)) setCell(xtemp, ytemp, wall);
            else if (xtemp == (x+(xlen-1)/2)) setCell(xtemp, ytemp, wall);
            else if (ytemp == y) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y-ylen+1)) setCell(xtemp, ytemp, wall);
            //and then fill with the floor
            else setCell(xtemp, ytemp, floor);
          }
        }
  
        break;
  
      case 1: // east
  
        for (int ytemp = (y-ylen/2); ytemp < (y+(ylen+1)/2); ytemp++) {
          if (ytemp < 0 || ytemp > ysize) return false;
          for (int xtemp = x; xtemp < (x+xlen); xtemp++) {
            if (xtemp < 0 || xtemp > xsize) return false;
            if (getCell(xtemp, ytemp) != tileUnused) return false;
          }
        }
  
        for (int ytemp = (y-ylen/2); ytemp < (y+(ylen+1)/2); ytemp++) {
          for (int xtemp = x; xtemp < (x+xlen); xtemp++) {
            if (xtemp == x) setCell(xtemp, ytemp, wall);
            else if (xtemp == (x+xlen-1)) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y-ylen/2)) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y+(ylen-1)/2)) setCell(xtemp, ytemp, wall);
            else setCell(xtemp, ytemp, floor);
          }
        }
  
        break;
  
      case 2: // south
  
        for (int ytemp = y; ytemp < (y+ylen); ytemp++) {
          if (ytemp < 0 || ytemp > ysize) return false;
          for (int xtemp = (x-xlen/2); xtemp < (x+(xlen+1)/2); xtemp++) {
            if (xtemp < 0 || xtemp > xsize) return false;
            if (getCell(xtemp, ytemp) != tileUnused) return false;
          }
        }

        for (int ytemp = y; ytemp < (y+ylen); ytemp++) {
          for (int xtemp = (x-xlen/2); xtemp < (x+(xlen+1)/2); xtemp++) {
            if (xtemp == (x-xlen/2)) setCell(xtemp, ytemp, wall);
            else if (xtemp == (x+(xlen-1)/2)) setCell(xtemp, ytemp, wall);
            else if (ytemp == y) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y+ylen-1)) setCell(xtemp, ytemp, wall);
            else setCell(xtemp, ytemp, floor);
          }
        }
  
        break;
  
      case 3: // west
  
        for (int ytemp = (y-ylen/2); ytemp < (y+(ylen+1)/2); ytemp++) {
          if (ytemp < 0 || ytemp > ysize) return false;
          for (int xtemp = x; xtemp > (x-xlen); xtemp--) {
            if (xtemp < 0 || xtemp > xsize) return false;
            if (getCell(xtemp, ytemp) != tileUnused) return false;
          }
        }
  
        for (int ytemp = (y-ylen/2); ytemp < (y+(ylen+1)/2); ytemp++) {
          for (int xtemp = x; xtemp > (x-xlen); xtemp--) {
            if (xtemp == x) setCell(xtemp, ytemp, wall);
            else if (xtemp == (x-xlen+1)) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y-ylen/2)) setCell(xtemp, ytemp, wall);
            else if (ytemp == (y+(ylen-1)/2)) setCell(xtemp, ytemp, wall);
            else setCell(xtemp, ytemp, floor);
          }
        }
  
        break;
      }

    //yay, all done
    return true;
  }
}
/* Procedural Content Generation
   Cellular Automata
   Based on algorithm by Jim Babcock
   http://www.jimrandomh.org/misc/caves.html */

class PCGCa extends PCG {
  byte[][] cagrid; // Grid array
  int r1_cutoff = 5;
  int r2_cutoff = 2;
  int iter1;
  int iter2;
  int prob;
    
  PCGCa()
  {
  }

  public void updateParam(int g_width, int g_height, int w_fill, int it1, int it2)
  {
    super.updateParam(g_width, g_height);
    prob = w_fill; // Fill percentage
    iter1 = it1; // Number of iterations
    iter2 = it2; // Number of iterations for well-formedness
  }
  
  public void generatePCGCa(byte[][] g)
  {
    super.generatePCG(g); // Init grid 
    
    initMap(); // Fill map randomly
    
    // CA iterate
    for (int i = 0; i < iter1; i++) {
      cellularAutomata(r1_cutoff, r2_cutoff); 
    }
    // Cleanup interate
    for (int i = 0; i < iter2; i++) {
      cellularAutomata(r1_cutoff, -1); 
    }
  }
  
  public byte randomPick()
  {
    // Return a random value based on probability
    if (PApplet.parseInt(random(100)) > (100 - prob)) return 0;
    else return 1;    
  }
  
  public void initMap()
  {
    cagrid = new byte[pcgrid_width][pcgrid_height];
    // Initialize random grid
    for (int j = 0; j < pcgrid_height - 1; j++) {
      for (int i = 0; i < pcgrid_width - 1; i++) {
        pcgrid[i][j] = randomPick();
      }
    }
    // Initialize 2nd grid
    for (int j = 0; j < pcgrid_height; j++) {
      for (int i = 0; i < pcgrid_width; i++) {
        cagrid[i][j] = 0;
      }
    }
    // Set walls
    for (int i = 0; i < pcgrid_width; i++) { pcgrid[i][0] = 0 ; pcgrid[i][pcgrid_height - 1] = 0; }
    for (int j = 0; j < pcgrid_height; j++) { pcgrid[0][j] = 0; pcgrid[pcgrid_width - 1][j] = 0; }
  }

  public void cellularAutomata(int r1, int r2)
  {
    for (int j = 1; j < pcgrid_height - 1; j++) {
      for (int i = 1; i < pcgrid_width - 1; i++) {
        int adjcount_r1 = 0; // Adjacent tiles within 1 step of P
        int adjcount_r2 = 0; // Adjacent tiles within 2 step of P
        
        for (int jj = -1; jj <= 1; jj++) {
          for (int ii = -1; ii <= 1; ii++) {
            // Count number of walls around T within radius 1
            if (pcgrid[i + ii][j + jj] != 1) adjcount_r1++;
          }
        }
        for (int jj = j - 2; jj <= j + 2; jj++) {
          for (int ii = i - 2; ii <= i + 2; ii++) {
            // Count number of walls around T within radius 2
            if (abs(ii - i) == 2 && abs(jj - j) == 2) continue; // If is n2
            if (ii < 0 || jj < 0 || ii >= pcgrid_width || jj >= pcgrid_height) continue; // Bounded
            if (pcgrid[ii][jj] != 1) adjcount_r2++;
          }
        }
        
        if (adjcount_r1 >= r1 || adjcount_r2 <= r2) cagrid[i][j] = 0;
 	else cagrid[i][j] = 1;
      }
    }
    
    for (int j = 1; j < pcgrid_height - 1; j++) {
      for (int i = 1; i < pcgrid_width - 1; i++) {
        pcgrid[i][j] = cagrid[i][j];
      }
    }  
  }
}
public void renderInfo()
{
  // Render info
  if (d_show) {
    fill(230);
    text("Press 'space' to generate", 15, 20);
    fill(0);
    stroke(150);
    rect(15, 30, 10, 10);
    fill(230);
    text("Empty", 30, 40);
    fill(255);
    stroke(150);
    rect(15, 45, 10, 10);
    fill(230);
    text("Floor", 30, 55);
    fill(200);
    stroke(150);
    rect(15, 60, 10, 10);
    fill(230);
    text("Wall", 30, 70);
    fill(0, 102, 153);
    stroke(150);
    rect(15, 75, 10, 10);
    fill(230);
    text("Door", 30, 85);
    fill(64, 102, 104);
    stroke(150);
    rect(15, 90, 10, 10);
    fill(230);
    text("BSP node border", 30, 100);
  }  
}

public void renderGrid()
{
  // Render grid
  for (int j = 0; j < world.grid_height; j++) {
    for (int i = 0; i < world.grid_width; i++) {
      renderGridCell(i, j);
    }
  }
}

public void renderGridCell(int x, int y)
{
  // Render grid cell content
  switch (world.grid[x][y]) {
    case 0: // Empty
      fill(0);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
    case 1: // Floor
      fill(255);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
    case 2: // Wall
      if (world.debug) fill(200);
      else fill(255);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
    case 3: // Door
      if (world.debug) fill(0, 102, 153);
      else fill(255);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
    case 4: // Corridor
      fill(255);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
    case 5: // BSP border
      if (world.debug) fill(64, 102, 104);
      else fill(0);
      if (world.show_grid) stroke(150);
      else noStroke();
      rect(x*10, y*10, 10, 10);
      break;
  }
}
class World {
  PCG pcg; // Procedural Content Generation grid
  PCGBasic pcgb; // Procedural Content Generation grid Basic
  PCGCa pcgca; // Procedural Content Generation grid Cellular Automata
  PCGBSP pcgbsp; // Procedural Content Generation grid BSP
  PCGBuild pcgbd; // Procedural Content Generation grid Grow
  int pcg_type; // PCG type
  
  byte[][] grid; // Grid array
  boolean show_grid = true; // Show grid
  int grid_width; // Grid width
  int grid_height; // Grid height
  
  boolean debug = true; // Debug mode
  
  // World parameters  
  World()
  {
    generateWorld(1, 40, 30);
  }
  
  public void generateWorld(int p_t, int g_w, int g_h)
  {
    pcg_type = p_t; // PGC type
    grid_width = g_w; // Grid width
    grid_height = g_h; // Grid height
    
    initGrid(); // Initialize empty grid
    
    // Generate PCG
    switch (pcg_type) {
      case 0: pcg = new PCG();
              pcg.updateParam(grid_width, grid_height);
              pcg.generatePCG(grid);
              break;
      case 1: pcgb = new PCGBasic();
              pcgb.updateParam(grid_width, grid_height, room_type, room_min_size, room_max_size, corridor_num, corridor_weight, turning_weight);
              pcgb.generatePCGBasic(grid);
              break;
      case 2: pcgca = new PCGCa();
              pcgca.updateParam(grid_width, grid_height, wall_fill, generate_iter, cleanup_iter);
              pcgca.generatePCGCa(grid);
              break;
      case 3: pcgbsp = new PCGBSP();
              pcgbsp.updateParam(grid_width, grid_height, min_room_num, min_room_size);
              pcgbsp.generatePCGBSP(grid);
              break;
      case 4: pcgbd = new PCGBuild();
              pcgbd.updateParam(grid_width, grid_height, max_rm_w, max_rm_h, max_corr_l, obj_num);
              pcgbd.generatePCGBuild(grid);
              break;
    }
  }
  
  public void randomWorld()
  {
    g_layout = PApplet.parseInt(random(1, 4));
    switch (g_layout) {
      case 0: cp5.getController("Layouts").getCaptionLabel().set("Basic"); break;
      case 1: cp5.getController("Layouts").getCaptionLabel().set("Cave"); break;
      case 2: cp5.getController("Layouts").getCaptionLabel().set("BSP"); break;
      case 3: cp5.getController("Layouts").getCaptionLabel().set("Build"); break;
    }       
    if (g_layout == 0) {
      switch (room_type) {
        case 0: cp5.getController("Room").setLabel("Scattered"); break;
        case 1: cp5.getController("Room").setLabel("Sparse"); break;
        case 2: cp5.getController("Room").setLabel("Dense"); break;
        case 3: cp5.getController("Room").setLabel("Complex"); break;
      }
      cp5.getController("Room").unlock();
    }
    else {
      cp5.getController("Room").lock();
      cp5.getController("Room").setLabel("N/A");
    }
    g_width = PApplet.parseInt(random(10, 50));
    cp5.getController("g_width").setValue(g_width);
    g_height = PApplet.parseInt(random(10, 50));
    cp5.getController("g_height").setValue(g_height);
    generateWorld(g_layout, g_width, g_height);
  }
  
  public void updateParam(boolean g_s, boolean d_s)
  {
    show_grid = g_s; // Display grid
    debug = d_s; // Display debug info
  }
  
  public void initGrid()
  {
    grid = new byte[grid_width][grid_height]; 
    
    for (int j = 0; j < grid_height; j++) {
      for (int i = 0; i < grid_width; i++) {
        grid[i][j] = 0; // Initialize all cell as empty
      }
    }
  }
}
  public void settings() {  size(800, 600);  noSmooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "DungeonGenerator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
